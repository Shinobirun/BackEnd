package com.porfolio.primerporfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerporfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
